#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <curl/curl.h>

#define MAX_BUF_SIZE 1024

typedef struct {
    FILE *file;
    char *fileName;
} FileData;

size_t writeData(void *ptr, size_t size, size_t nmemb, void *userdata) {
    FileData *data = (FileData *)userdata;
    return fwrite(ptr, size, nmemb, data->file);
}

void downloadFile(char *url) {
    char *fileName = strrchr(url, '/');
    if(fileName == NULL) {
        printf("Invalid URL\n");
        return;
    }
    fileName++;

    CURL *curl = curl_easy_init();
    if(curl) {
        FILE *file = fopen(fileName, "wb");
        if(file == NULL) {
            printf("Error creating file\n");
            return;
        }

        FileData data = {file, fileName};

        curl_easy_setopt(curl, CURLOPT_URL, url);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeData);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &data);

        CURLcode res = curl_easy_perform(curl);
        if(res != CURLE_OK) {
            printf("Error downloading file: %s\n", curl_easy_strerror(res));
        }

        fclose(file);
        curl_easy_cleanup(curl);

        printf("File downloaded successfully: %s\n", fileName);
    } else {
        printf("Error initializing curl\n");
    }
}

int main(int argc, char *argv[]) {
    if(argc != 2) {
        printf("Usage: %s <URL>\n", argv[0]);
        return 1;
    }

    curl_global_init(CURL_GLOBAL_ALL);
    downloadFile(argv[1]);
    curl_global_cleanup();

    return 0;
}
